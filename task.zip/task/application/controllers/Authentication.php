<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

// Load the Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';

class Authentication extends REST_Controller {

    public function __construct() { 
        parent::__construct();
        
        // Load the user model
        $this->load->model('user');
		 $this->load->model('incident');
		$this->load->library('form_validation');
        $this->load->library('email');
	    $this->load->helper('url');
		$this->load->helper('custom');
    }
    
   
    public function registration_post() {
		 
        // Get the post data
		$first_name = strip_tags($this->post('first_name'));
		$last_name = strip_tags($this->post('last_name'));
        $username = strip_tags($this->post('username'));
        $email = strip_tags($this->input->post('email'));
        $password = $this->input->post('password');
        $phone = strip_tags($this->input->post('phone'));
		$address = strip_tags($this->post('address'));
		$pincode = strip_tags($this->post('pincode'));
		$city = strip_tags($this->post('city'));
		$country = strip_tags($this->post('country'));
        
        // Validate the post data
        if(!empty($username) && !empty($phone) && !empty($email) && !empty($password)){
           
            // Check if the given email already exists
            $con['returnType'] = 'count';
            $con['conditions'] = array(
                'email' => $email,
				'username'=>$username
            );
            $userCount = $this->user->getRows($con);
            
            if(!empty($userCount) ){
                
                $this->response([
                        'status' => FALSE,
                        'message' => 'The given email OR Username already exists.',
                        'data' => array()
                    ], REST_Controller::HTTP_BAD_REQUEST);
            }else{
                // Insert user data
                $userData = array(
					'first_name' => $first_name,
					'last_name' => $last_name,
                    'username' => $username,
                    'email' => $email,
                    'password' => md5($password),
                    'phone' => $phone,
					'address' => $address,
					'pincode' => $pincode,
					'city' => $city,
					'country' =>$country
					
					
                );
                $insert = $this->user->insert($userData);
                
                // Check if the user data is inserted
                if($insert){
                    // Set the response and exit
                    $this->response([
                        'status' => TRUE,
                        'message' => 'The user has been added successfully.',
                        'data' => $insert
                    ], REST_Controller::HTTP_OK);
                }else{
                    // Set the response and exit
                    $this->response("Some problems occurred, please try again.", REST_Controller::HTTP_BAD_REQUEST);
                }
            }
        }else{
            // Set the response and exit
            $this->response("Provide complete user info to add.", REST_Controller::HTTP_BAD_REQUEST);
        }
    }
    
	
	  public function login_post() {
        // Get the post data

        $username = $this->input->post('username');
        $password = $this->input->post('password');
        
        // Validate the post data
        if(!empty($username) && !empty($password)){
            
            // Check if any user exists with the given credentials
           
            $con['conditions'] = array(
                'username' => $username,
                'password' => md5($password),
                'status' => 1
            );
            $user = $this->user->getRows($con);
			
			
            
            if(!empty($user)){
				$token = bin2hex(random_bytes(16));
                $this->user->update_token($user->id, $token);
				$users = $this->user->getRows($con);
                // Set the response and exit
                $this->response([
                    'status' => TRUE,
                    'message' => 'User login successful.',
                   'token' => $token
                ], REST_Controller::HTTP_OK);
            }else{
                // Set the response and exit
                //BAD_REQUEST (400) being the HTTP response code
                $this->response("Wrong email or password.", REST_Controller::HTTP_BAD_REQUEST);
            }
        }else{
            // Set the response and exit
            $this->response("Provide email and password.", REST_Controller::HTTP_BAD_REQUEST);
        }
    }


    public function forgot_password_post() {
		
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');

        if ($this->form_validation->run() == FALSE) {
            $response = array(
                'status' => false,
                'message' => validation_errors()
            );
            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($response));
        } else {
             $email = $this->input->post('email');
			
            $user = $this->user->user_by_email($email);

            if ($user) {
                $reset_token = bin2hex(random_bytes(16));
                $this->user->password_reset_token($user['id'], $reset_token);

                $reset_link = base_url('reset_password/' . $reset_token);
                $message = "Click the following link to reset your password: " . $reset_link;

                $this->email->from('manishkasimpur@gmail.com', 'Your Site Name');
                $this->email->to($email);
                $this->email->subject('Password Reset Request');
                $this->email->message($message);

                if ($this->email->send()) {
                    $response = array(
                        'status' => true,
                        'message' => 'A password reset link has been sent to your email address.'
                    );
                } else {
                    $response = array(
                        'status' => false,
                        'message' => 'Failed to send the password reset email. Please try again later.'
                    );
                }
            } else {
                $response = array(
                    'status' => false,
                    'message' => 'No user found with this email address.'
                );
            }

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($response));
        }
    }
	
	 private function verify_token() {
        $headers = $this->input->request_headers();
        $token = isset($headers['token']) ? $headers['token'] : '';

        if ($token) {
            $user = $this->user->verify_token($token);
            if ($user) {
                return $user;
            }
        }

        $this->response(['status' => false, 'message' => 'Unauthorized'], REST_Controller::HTTP_UNAUTHORIZED);
        exit;
    }
	
	

    public function create_incident_post() {
        $user = $this->verify_token();
			
        $this->form_validation->set_rules('title', 'Title', 'required');
        $this->form_validation->set_rules('description', 'Description', 'required');
		$this->form_validation->set_rules('identify', 'Incident Identify', 'required');
		$this->form_validation->set_rules('incident_date', 'Incident Date', 'required');
		$this->form_validation->set_rules('incident_time', 'Incident Time', 'required');
		$this->form_validation->set_rules('incident_priority', 'Incident Priority', 'required');
		$this->form_validation->set_rules('incident_status', 'Incident Status', 'required');
		

        if($this->form_validation->run() == FALSE) {
            $this->response(['status' => false, 'message' => validation_errors()], REST_Controller::HTTP_BAD_REQUEST);
        } else {
			$incidentID = generate_incident_id();
            $data = [
                'user_id' => $user->id,
                'title' => $this->input->post('title'),
                'incident_details' => $this->input->post('description'),
				'identify' => $this->input->post('identify'),
				'incident_id' => $incidentID,
				'reporter_name' =>$user->username,
				'incident_date' =>$this->input->post('incident_date'),
				'incident_time' =>$this->input->post('incident_time'),
				'incident_priority' => $this->input->post('incident_priority'),
				'incident_status'=> $this->input->post('incident_status'),
                'created_at' => date('Y-m-d H:i:s')
            ];

            $incident_id = $this->incident->create_incident($data);
            if ($incident_id) {
                $this->response(['status' => true, 'message' => 'Incident created successfully', 'incident_id' => $incident_id], REST_Controller::HTTP_OK);
            } else {
                $this->response(['status' => false, 'message' => 'Failed to create incident'], REST_Controller::HTTP_INTERNAL_SERVER_ERROR);
            }
        }
    }
	
	 public function user_incident_get($incidentId = 0) {
       $user = $this->verify_token();
       
		   $con['conditions'] = array('incident_id' => $incidentId,'user_id'=>$user->id);
        $incidents = $this->incident->getincidentRows($con);
        
      
        if(!empty($incidents)){
         
            $this->response($incidents, REST_Controller::HTTP_OK);
        }else{
            // Set the response and exit
            //NOT_FOUND (404) being the HTTP response code
            $this->response([
                'status' => FALSE,
                'message' => 'No incident was found.'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }
	
	public function update_incident_post($incidentId) {
         $user = $this->verify_token();
			
        if (!empty($user)) {
        
            $this->form_validation->set_rules('title', 'Title', 'required');
			$this->form_validation->set_rules('description', 'Description', 'required');
			$this->form_validation->set_rules('identify', 'Incident Identify', 'required');
			$this->form_validation->set_rules('incident_date', 'Incident Date', 'required');
			$this->form_validation->set_rules('incident_time', 'Incident Time', 'required');
			$this->form_validation->set_rules('incident_priority', 'Incident Priority', 'required');
			$this->form_validation->set_rules('incident_status', 'Incident Status', 'required');
			
            if ($this->form_validation->run() == FALSE) {
                $this->response([
                    'status' => FALSE,
                    'message' => validation_errors()
                ], REST_Controller::HTTP_BAD_REQUEST);
            } else {
                $update_data = [
                     'title' => $this->input->post('title'),
                'incident_details' => $this->input->post('description'),
				'identify' => $this->input->post('identify'),
				
				'incident_date' =>$this->input->post('incident_date'),
				'incident_time' =>$this->input->post('incident_time'),
				'incident_priority' => $this->input->post('incident_priority'),
				'incident_status'=> $this->input->post('incident_status')
                    
                ];
				
                $result = $this->incident->update_incident($incidentId, $update_data);

                if ($result) {
                    $this->response([
                        'status' => TRUE,
                        'message' => 'Incident updated successfully'
                    ], REST_Controller::HTTP_OK);
                } else {
                    $this->response([
                        'status' => FALSE,
                        'message' => 'Failed to update incident'
                    ], REST_Controller::HTTP_INTERNAL_SERVER_ERROR);
                }
            }
        } else {
            $this->response([
                'status' => FALSE,
                'message' => 'Unauthorized'
            ], REST_Controller::HTTP_UNAUTHORIZED);
        }
    }
	
	
	
	
	
	
	

}