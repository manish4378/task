<?php
if (!function_exists('generate_incident_id')) {
    function generate_incident_id() {
        $prefix = 'RMG';
        $randomNumber = mt_rand(10000, 99999); // Generate a random 5-digit number
        $year = date('Y'); // Get the current year
        return $prefix . $randomNumber . $year;
    }
}
