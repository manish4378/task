<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class User extends CI_Model {

    public function __construct() {
        parent::__construct();
        
        // Load the database library
        $this->load->database();
        
        $this->userTbl = 'users';
		 $this->incidentTbl = 'incident';
    }

    /*
     * Get rows from the users table
     */
    public function getRows($params = array()){
    $this->db->select('*');
    $this->db->from($this->userTbl);
    
    // Fetch data by conditions
	 
    
    if(!empty($params)){
		if(!empty($params['conditions']['username']))
		{
        $this->db->where('username', $params['conditions']['username'] );
		}
		if(!empty( $params['conditions']['email']))
		{
		 $this->db->or_where('email', $params['conditions']['email']);
		}
		
		if(!empty( $params['conditions']['password']))
		{
		 $this->db->where('password', $params['conditions']['password']);
		  
		}
		
		 $query = $this->db->get();
         $result = $query->row();
		
    }
    
    // Return fetched data
    return $result;
}

    /*
     * Insert user data
     */
    public function insert($data){
        //add created and modified date if not exists
        if(!array_key_exists("created_at", $data)){
            $data['created_at'] = date("Y-m-d H:i:s");
        }
        if(!array_key_exists("updated_at", $data)){
            $data['updated_at'] = date("Y-m-d H:i:s");
        }
        
        //insert user data to users table
        $insert = $this->db->insert($this->userTbl, $data);
        
        //return the status
        return $insert?$this->db->insert_id():false;
    }
	
	  /*
     *  user data by email
     */
        public function user_by_email($email) {
        $this->db->where('email', $email);
        $query = $this->db->get('users');
        return $query->row_array();
    }

    public function password_reset_token($user_id, $token) {
        $data = array(
            'password_reset_token' => $token,
            'token_created_at' => date('Y-m-d H:i:s')
        );
        $this->db->where('id', $user_id);
        return $this->db->update('users', $data);
    }
	
	public function update_token($user_id, $token) {
        $this->db->where('id', $user_id);
        $this->db->update('users', ['token' => $token]);
    }
	
	 public function verify_token($token) {
        $this->db->where('token', $token);
        $query = $this->db->get('users');
	
        return $query->row();
    }
   
}