<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
	class Incident extends CI_Model {
	
	  public function __construct() {
        parent::__construct();
        
        // Load the database library
        $this->load->database();
        
        $this->userTbl = 'users';
		$this->incidentTbl = 'incident';
    }

    public function create_incident($data) {
        $this->db->insert( $this->incidentTbl, $data);
        return $this->db->insert_id();
    }
	
	
	  public function getincidentRows($params = array()) {
        
		        $this->db->select('incident.*, users.username as reporter_name');
        $this->db->from('incident');
        $this->db->join('users', 'incident.user_id = users.id', 'left');
      

		
		
		if(!empty($params)){
		if(!empty($params['conditions']['incident_id']))
		{
        $this->db->where('incident.incident_id', $params['conditions']['incident_id'] );
		 $this->db->where('incident.incident_status!=', 'Closed' );
		  $this->db->where('incident.user_id', $params['conditions']['user_id']);
		
		}
		 $query = $this->db->get();
         $result = $query->row();
		}
		return $result;
		}
		public function update_incident($id, $data) {
        $this->db->where('incident_id', $id);
	
        return $this->db->update('incident', $data);
    }

		
	}